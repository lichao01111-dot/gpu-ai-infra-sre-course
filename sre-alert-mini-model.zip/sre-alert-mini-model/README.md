# SRE 告警小模型：从 CSV 到可预测的模型

这是课程第 14 章的配套实操。它用 48 条**合成练习告警**训练一个 CPU 可运行的文本分类器，预测四类故障。压缩包附带一次实际训练生成的 `model.joblib`，下载解压后可以直接预测；也可以自己重训。它是教学用小模型，不用于真实生产告警。

## 你会做出什么

输入一条告警，程序给出一个故障类别、一项固定的 runbook 检查建议，以及模型分数。模型只做分类；建议由代码中的安全映射提供，不让模型自由编造处置命令。

## 先准备环境

需要 Python 3.10 或更新版本。打开终端，进入这个项目文件夹：

```bash
cd sre-alert-mini-model
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

Windows PowerShell 激活虚拟环境的命令是：

```powershell
.venv\Scripts\Activate.ps1
```

## 训练

```bash
python src/train.py
```

训练脚本会读取 `data/alerts.csv`，按类别分层切成训练集和测试集，训练模型，打印测试报告，并覆盖保存 `model.joblib`。随附模型这次运行留出了 12 条测试样本，准确率为 0.83（10/12）；样本太少，这个数字只用于讲解报告，不能理解成生产准确率。

## 让模型分析一条新告警

```bash
python src/predict.py --text "checkout-api DB pool active 100/100, idle 0; connection timeout rising"
```

换一类试试：

```bash
python src/predict.py --text "node-7 根分区 97%，磁盘每小时增长 2GB"
```

## 看懂训练过程

1. `data/alerts.csv` 是练习数据。`text` 是输入，`label` 是人写的标准类别。
2. `train_test_split` 留出测试样本，训练时不拿它教模型。
3. TF-IDF 把文本片段变成数字；逻辑回归从这些数字里学习类别边界。
4. 分类报告中的 `recall` 表示某类真实告警有多少被找出来。漏掉 P1 类型比总体准确率更值得关注。
5. `predict.py` 加载保存的模型，对从未见过的文字做预测。

## 轮到你改数据

复制 `alerts.csv`，每类至少补 10 条与你练习环境接近、且已脱敏的告警。不要把同一条告警的轻微改写同时放进训练数据和测试数据。改完重跑训练，然后检查每类 recall 和误分类样本。

## 第二阶段：LoRA 微调语言模型

项目的 `lora/` 子目录有独立的数据、训练脚本、预测脚本和操作说明。它会加载 Qwen2.5-0.5B-Instruct，在 CUDA GPU 上训练 LoRA adapter，并可用同一输入对比微调前后结果。按 `lora/README.md` 操作；这一阶段需要 NVIDIA GPU，不是 CPU 分类器的一部分。

两阶段解决的问题不同：第一阶段从标注数据训练固定类别分类器，运行简单、输出可控；第二阶段让已有语言模型学习按 JSON 格式整理告警，表达更灵活，但更耗资源，也可能编造信息。

## 安全边界

样本是合成的。接入真实数据前先脱敏；上线前要用独立、真实且有人工标注的测试集评估。模型分数不是风险概率。模型建议只供值班人员参考，不自动重启、扩容、删文件或改生产配置。
