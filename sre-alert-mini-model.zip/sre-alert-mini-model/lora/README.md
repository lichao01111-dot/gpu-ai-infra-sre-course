# 第二阶段：LoRA 微调一个现成的小语言模型

本目录和项目根目录的 CPU 分类器是两个练习。建议先完成根目录的分类器，再做这里的 LoRA。基座模型是 `Qwen/Qwen2.5-0.5B-Instruct`；数据仍是 48 条合成告警，但答案改成“告警 → JSON”，让语言模型学习按格式输出。

## 环境要求

需要 Linux、Python 3.10–3.12、NVIDIA GPU 和可用的 CUDA 版 PyTorch。建议 8 GB 以上显存做入门实验；显存够不够还受驱动、PyTorch、序列长度和系统占用影响。普通笔记本没有合适 NVIDIA GPU 时，先停留在 CPU 分类器，不要为这一步安装驱动。

先按 [PyTorch 官方安装选择器](https://pytorch.org/get-started/locally/) 安装与你机器匹配的 CUDA 版 PyTorch。再进入本目录安装其余依赖：

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

首次运行会从 Hugging Face 下载约 0.5B 参数基座模型，需联网并预留磁盘空间。检查该模型当前许可与使用条件：[Qwen2.5-0.5B-Instruct 模型卡](https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct)。

## 先看训练样本

`data/train.jsonl` 每行是一个样本，字段为 `instruction`（任务要求）、`input`（告警）和 `output`（标准 JSON 答案）。训练代码把三部分按模型自己的 chat template 拼成对话，再用 LoRA 只训练少量 adapter 参数。训练代码只对 assistant 的标准答案计算 loss，不让模型把输入提示也作为目标去背。对话模板为什么重要，可读 [Transformers 官方说明](https://huggingface.co/docs/transformers/chat_templating)。

## 微调

```bash
python src/train.py
```

脚本会做 80/20 训练与评估切分，加载基座模型、添加 LoRA adapter、训练 3 轮，并把 adapter 保存到 `adapter/`。它不会重训模型全部参数。训练过程中的 eval loss 只是训练信号，不代表 SRE 业务正确率。

## 比较微调前后

先运行原模型：

```bash
python src/predict.py --base-only --text "checkout-api DB pool active=100/100, idle=0, connection timeout rising"
```

再加载刚训练的 adapter：

```bash
python src/predict.py --text "checkout-api DB pool active=100/100, idle=0, connection timeout rising"
```

对至少 10 条**没有进入训练文件**的告警记录原模型和微调模型的类别是否正确、JSON 是否有效、依据是否来自输入、建议是否越权。小数据微调可能让模型记住样本，结果也可能不如原模型；如实记录错误，不要只挑成功例子。

## 认识它的边界

这是一份教学脚手架，不是生产模型。48 条合成数据不足以让语言模型可靠处理真实值班事件。LoRA 不能注入最新事实，也不能保证模型不编造；生产建议仍须人工审核。更完整的 LoRA API 说明见 [PEFT 官方文档](https://huggingface.co/docs/peft/package_reference/lora)。
