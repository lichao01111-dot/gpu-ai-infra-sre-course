from pathlib import Path
import json

import torch
from datasets import Dataset
from peft import LoraConfig, get_peft_model, TaskType
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
)

ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = ROOT / "data" / "train.jsonl"
OUTPUT_DIR = ROOT / "adapter"
MODEL_ID = "Qwen/Qwen2.5-0.5B-Instruct"
MAX_LENGTH = 512


def main():
    if not torch.cuda.is_available():
        raise SystemExit(
            "LoRA 实操需要 NVIDIA CUDA GPU。请在带 GPU 的 Linux 云主机运行；"
            "CPU 小分类器请回到项目根目录运行 python src/train.py。"
        )

    tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    rows = [json.loads(line) for line in DATA_FILE.read_text(encoding="utf-8").splitlines() if line.strip()]
    dataset = Dataset.from_list(rows).train_test_split(test_size=0.2, seed=42)

    def to_tokens(row):
        messages = [
            {"role": "system", "content": row["instruction"]},
            {"role": "user", "content": row["input"]},
            {"role": "assistant", "content": row["output"]},
        ]
        prompt_ids = tokenizer.apply_chat_template(messages[:2], tokenize=True, add_generation_prompt=True)
        all_ids = tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=False)
        all_ids = all_ids[:MAX_LENGTH]
        prompt_length = min(len(prompt_ids), len(all_ids))
        return {
            "input_ids": all_ids,
            "attention_mask": [1] * len(all_ids),
            # 只让模型学习 assistant 的标准答案，不让它把告警输入也当成答案背下来。
            "labels": [-100] * prompt_length + all_ids[prompt_length:],
        }

    tokenized = dataset.map(to_tokens, remove_columns=dataset["train"].column_names)
    dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
    base = AutoModelForCausalLM.from_pretrained(MODEL_ID, torch_dtype=dtype)
    base.config.use_cache = False
    model = get_peft_model(base, LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=8,
        lora_alpha=16,
        lora_dropout=0.05,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    ))
    model.enable_input_require_grads()
    model.print_trainable_parameters()

    def collate(features):
        width = max(len(item["input_ids"]) for item in features)
        input_ids = torch.full((len(features), width), tokenizer.pad_token_id, dtype=torch.long)
        attention_mask = torch.zeros((len(features), width), dtype=torch.long)
        labels = torch.full((len(features), width), -100, dtype=torch.long)
        for row, item in enumerate(features):
            size = len(item["input_ids"])
            input_ids[row, :size] = torch.tensor(item["input_ids"], dtype=torch.long)
            attention_mask[row, :size] = 1
            labels[row, :size] = torch.tensor(item["labels"], dtype=torch.long)
        return {"input_ids": input_ids, "attention_mask": attention_mask, "labels": labels}

    args = TrainingArguments(
        output_dir=str(OUTPUT_DIR / "checkpoints"),
        num_train_epochs=3,
        per_device_train_batch_size=1,
        per_device_eval_batch_size=1,
        gradient_accumulation_steps=8,
        gradient_checkpointing=True,
        learning_rate=2e-4,
        logging_steps=1,
        eval_strategy="epoch",
        save_strategy="epoch",
        save_total_limit=2,
        fp16=dtype == torch.float16,
        bf16=dtype == torch.bfloat16,
        report_to="none",
    )
    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=tokenized["train"],
        eval_dataset=tokenized["test"],
        data_collator=collate,
    )
    trainer.train()
    model.save_pretrained(OUTPUT_DIR)
    tokenizer.save_pretrained(OUTPUT_DIR)
    print(f"LoRA adapter 已保存到：{OUTPUT_DIR}")
    print("评估 loss 不能代替告警业务评测；请用未参与训练的告警人工检查类别、依据和安全建议。")


if __name__ == "__main__":
    main()
