from pathlib import Path
import argparse

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

MODEL_ID = "Qwen/Qwen2.5-0.5B-Instruct"
ROOT = Path(__file__).resolve().parents[1]
ADAPTER = ROOT / "adapter"


def main():
    parser = argparse.ArgumentParser(description="比较基座模型或加载 LoRA adapter 分析 SRE 告警")
    parser.add_argument("--text", required=True, help="告警或日志文本")
    parser.add_argument("--base-only", action="store_true", help="只运行原始模型，作为微调前对照")
    args = parser.parse_args()

    if not torch.cuda.is_available():
        raise SystemExit("该示例需要 NVIDIA CUDA GPU；CPU 分类器不需要 GPU。")
    if not args.base_only and not ADAPTER.exists():
        raise SystemExit("没有找到 LoRA adapter。请先运行 python src/train.py，或加 --base-only 试原模型。")

    tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
    model = AutoModelForCausalLM.from_pretrained(MODEL_ID, torch_dtype="auto", device_map="auto")
    if not args.base_only:
        model = PeftModel.from_pretrained(model, ADAPTER)
    model.eval()

    messages = [
        {"role": "system", "content": "你是 SRE 告警分类助手。只根据告警内容输出 JSON，字段为 category、reason、action。不能臆测未提供的事实，也不能执行操作。"},
        {"role": "user", "content": args.text},
    ]
    inputs = tokenizer.apply_chat_template(
        messages, tokenize=True, add_generation_prompt=True, return_tensors="pt", return_dict=True
    ).to(model.device)
    with torch.no_grad():
        output = model.generate(**inputs, max_new_tokens=160, do_sample=False)
    answer = tokenizer.decode(output[0][inputs["input_ids"].shape[1]:], skip_special_tokens=True)
    print(answer)
    print("\n模型生成内容必须人工核对，不能直接用于生产操作。")


if __name__ == "__main__":
    main()
