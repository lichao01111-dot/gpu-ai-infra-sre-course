from pathlib import Path
import argparse

import joblib

ROOT = Path(__file__).resolve().parents[1]
MODEL_FILE = ROOT / "model.joblib"
RUNBOOK = {
    "database_pool": "检查连接池使用数、数据库连接上限和慢查询；按现有 runbook 评估限流。",
    "disk_pressure": "先定位增长目录并确认日志轮转/保留策略；清理文件前按 runbook 核对。",
    "cpu_saturation": "检查热点进程、近期变更和请求队列；根据容量与 runbook 评估扩容。",
    "transient_restart": "检查重启原因并继续观察；当前证据不足以支持重启或其他变更。",
}


def main():
    parser = argparse.ArgumentParser(description="为一条告警预测故障类别")
    parser.add_argument("--text", required=True, help="告警或日志文本")
    args = parser.parse_args()

    if not MODEL_FILE.exists():
        raise SystemExit("还没有模型。请先在项目目录运行：python src/train.py")
    model = joblib.load(MODEL_FILE)
    probabilities = model.predict_proba([args.text])[0]
    best = probabilities.argmax()
    label = model.classes_[best]

    print(f"预测类别：{label}")
    print(f"模型分数：{probabilities[best]:.2f}（不是已校准的真实概率）")
    print(f"建议检查：{RUNBOOK[label]}")
    if probabilities[best] < 0.45:
        print("提示：分数较低，标记为需人工判断；不要据此自动操作生产系统。")


if __name__ == "__main__":
    main()
