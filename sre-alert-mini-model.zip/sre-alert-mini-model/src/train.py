from pathlib import Path
import csv
import json

import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = ROOT / "data" / "alerts.csv"
MODEL_FILE = ROOT / "model.joblib"
LABELS = ["database_pool", "disk_pressure", "cpu_saturation", "transient_restart"]


def main():
    with DATA_FILE.open(encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))

    texts = [row["text"].strip() for row in rows]
    labels = [row["label"].strip() for row in rows]
    if len(rows) < 8 or set(labels) != set(LABELS):
        raise ValueError("数据至少要有 8 条，并且四种 label 都要出现")

    x_train, x_test, y_train, y_test = train_test_split(
        texts, labels, test_size=0.25, random_state=42, stratify=labels
    )
    model = Pipeline([
        # 字符片段可以处理中文、英文和指标名；不需要先安装中文分词器。
        ("text", TfidfVectorizer(analyzer="char", ngram_range=(2, 4), min_df=1)),
        ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced")),
    ])
    model.fit(x_train, y_train)
    predicted = model.predict(x_test)

    print(f"总样本：{len(rows)}；训练：{len(x_train)}；测试：{len(x_test)}")
    print(f"测试集准确率：{accuracy_score(y_test, predicted):.2f}")
    print("\n每类表现（看 recall，判断这一类是否容易漏掉）：")
    print(classification_report(y_test, predicted, labels=LABELS, zero_division=0))
    print("混淆矩阵（行是真实类别，列是预测类别，顺序见上方 LABELS）：")
    print(confusion_matrix(y_test, predicted, labels=LABELS))

    joblib.dump(model, MODEL_FILE)
    print(f"\n模型已保存：{MODEL_FILE}")
    print("注意：这份小样本只用于学习流程，不能作为生产告警判定器。")


if __name__ == "__main__":
    main()
